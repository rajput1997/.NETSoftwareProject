﻿using DemoAPI.Contracts.Request;
using DemoAPI.Contracts.Response;
using DemoAPI.Respository.Contract;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private IUsers userService;
        public AccountController(IUsers users)
        {
            userService = users;
        }

        [HttpPost]
        public IActionResult SignIn(SignInModel model)
        {
            if (model != null)
            {
                var user = userService.SignIn(model);
                var apiResponse = new ApiResponse();
                if (user == null)
                {
                    //not found failure
                    apiResponse.Ok = false;
                    apiResponse.Status = 404;
                    apiResponse.Message = "Invalid login credentials !";
                    return Ok(apiResponse);
                }
                else
                {
                    //success login
                    apiResponse.Ok = true;
                    apiResponse.Status = 200;
                    apiResponse.Message = "Login success !";
                    apiResponse.Data = user;
                    apiResponse.Token = "?";
                    return Ok(apiResponse);
                }
            }
            else
            {
                return BadRequest();
            }

        }
        [HttpPost]
        public IActionResult SignUp(SignUpModel model)
        {
            if (model != null)
            {
                var user = userService.SignUp(model);
                var apiResponse = new ApiResponse();
               
                    apiResponse.Ok = true;
                    apiResponse.Status = 200;
                    apiResponse.Message = "user created successfully !";
                    apiResponse.Data = user;                  
                    return Ok(apiResponse);
                
            }
            else
            {
                return BadRequest();
            }
        }
    }
}
